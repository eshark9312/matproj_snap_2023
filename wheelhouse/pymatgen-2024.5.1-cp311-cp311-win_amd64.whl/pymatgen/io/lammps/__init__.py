"""IO for LAMMPS."""
