"""IO interface for FHI-aims."""
