"""This package contains various command line wrappers to programs used in
pymatgen that do not have Python equivalents.
"""
