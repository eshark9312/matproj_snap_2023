"""Optimization utilities."""
