"""Coordination geometry files."""
