"""Package for analyzing chemical environments."""
