"""Package for analyzing connectivity."""
