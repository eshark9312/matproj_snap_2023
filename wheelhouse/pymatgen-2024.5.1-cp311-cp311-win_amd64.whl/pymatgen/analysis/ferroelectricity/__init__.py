"""Package for analyzing ferroelectricity."""
